#! /bin/sh
cd "`dirname \"$0\"`"
./launcher/jre/bin/java -server -Xmx512M -jar launcher/launcher-trial.jar "${@}"