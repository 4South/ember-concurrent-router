
var options = new ExportOptionsPNG24();

var doc = app.activeDocument;

for (var i = 0; i < doc.layers.length; i++) {
	var layer = doc.layers[i];
	if (!layer.visible) continue;

	doc.activeLayer = layer;

	var newdoc = app.documents.add(doc.documentColorSpace, doc.width, doc.height);
	newdoc.artboards[0].artboardRect = doc.artboards[0].artboardRect;

	var newlayer = newdoc.layers[0];

	for (var ii = layer.pageItems.length - 1; ii >= 0; ii--)
		layer.pageItems[ii].duplicate(newlayer, ElementPlacement.PLACEATBEGINNING);

	new Folder(doc.path + '/png/').create();
	newdoc.exportFile(new File(doc.path + '/png/' + doc.activeLayer.name + ".png"), ExportType.PNG24, options);
	newdoc.close(SaveOptions.DONOTSAVECHANGES);
}
