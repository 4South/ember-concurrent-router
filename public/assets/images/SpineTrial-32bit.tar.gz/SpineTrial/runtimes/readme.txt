All official Spine runtimes are open source software.
Visit our github project for the latest source code, to submit patches, etc:
https://github.com/EsotericSoftware/spine-runtimes
Also see the runtime documentation:
http://esotericsoftware.com/spine-documentation/